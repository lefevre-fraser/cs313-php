<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
</head>
<body>
	<form action="adduser.php" method="post">
		<label>User Name:</label><br>
		<input type="text" name="user_name"><br>
		<label>Password:</label><br>
		<input type="password" name="password"><br>
		<button type="submit">Sign Up</button><br>
		<a href="signin.php">Have an Account? Sign In Here!</a>
	</form>
</body>
</html>